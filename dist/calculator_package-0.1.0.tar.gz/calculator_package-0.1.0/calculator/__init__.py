# This is __init__.py
from .arithmetic import add, subtract, multiply, divide
